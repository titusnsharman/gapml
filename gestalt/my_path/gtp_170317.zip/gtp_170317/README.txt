README.rtf

GTP computes the geodesic distance between two phylogenetic trees.

INSTALLATION
See manual.pdf for installation and execution instructions.

This version was last updated Aug. 5, 2014.
